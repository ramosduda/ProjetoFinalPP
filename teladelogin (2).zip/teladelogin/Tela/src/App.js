
import LoginProfissional from './Telas/LoginProfissional/LoginProfissional';
import LoginUsuario from './Telas/LoginUsuario/LoginUsuario';
import Principal from './Telas/Principal/Principal';
import React from 'react';


function App() {
  return (
    <>
    <Principal/>
    <LoginUsuario/>
    <LoginProfissional/>
    </ >
  );
}

export default App;
