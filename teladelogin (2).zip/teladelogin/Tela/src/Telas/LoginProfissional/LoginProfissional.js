import {ContainerLogin, LoginFormLogin, InputContainerLogin, PasswordLogin, InputContainer, SubmitButtonLogin, TittleLogin} from "./style.jsx"

function LoginProfissional() {
    return (
      <ContainerLogin>
        <TittleLogin>PROFISSIONAL</TittleLogin>
        <LoginFormLogin>
          <InputContainerLogin>
            <PasswordLogin htmlFor="username">PROFISSIONAL</PasswordLogin>
            <input type="text" id="username" placeholder="EMAIL" />
          </InputContainerLogin>
          <InputContainer>
            <label htmlFor="password"></label>
            <input type="password" id="password" placeholder="SENHA" />
          </InputContainer>
          <SubmitButtonLogin className="submit-button">ENVIAR</SubmitButtonLogin>
        </LoginFormLogin>
      </ContainerLogin>
    );
  }
  
  export default LoginProfissional;