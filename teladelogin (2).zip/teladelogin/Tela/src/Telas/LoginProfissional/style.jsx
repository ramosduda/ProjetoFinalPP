import styled from 'styled-components'

export const ContainerLogin = styled.div`
display: flex;
justify-content: center;
align-items: center;
height: 100vh;
background-color: #77AB5B;
margin: auto;
`
export const LoginFormLogin = styled.form`
background-color: #578543;
padding: 110px;
border-radius: 25px;
box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
justify-content: center;
justify-content: center;
`

export const InputContainerLogin = styled.div`
margin-bottom: 25px;
`

export const PasswordLogin = styled.label`
display: block;
font-size: 25px;
margin-bottom: 30px;
color: #ffffff;
font-family: "https://fonts.google.com/specimen/Baloo+Paaji+2";
padding-left: 35px;
`

export const InputContainer = styled.div`
margin-bottom: 10px;
border-radius: 20px;
`

export const SubmitButtonLogin = styled.button`
    background-color: #77AB5B;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 10px;
    font-size: 18px;
    cursor: pointer;
    transition: background-color 0.3s;
    margin-left: 30px;
    margin-top: 35px;

    &:hover{
        background-color: #77AB5B;
}
`
export const TittleLogin = styled.h1`
    font-size: 0px;
    color: white;
    
    /* margin-bottom: 5vh; */
`