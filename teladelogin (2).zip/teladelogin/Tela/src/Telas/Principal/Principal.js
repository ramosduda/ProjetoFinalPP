import { ContainerLogin, LoginFormLogin, SubmitButtonLogin, TittleLogin, SendButtonLogin, SubmitButton, DivEstilizada, TextoEstilizado } from "./style.jsx"

function Principal() {
  return (
    <ContainerLogin>
      <TittleLogin>NOVO PENSAMENTO</TittleLogin>

      <DivEstilizada>
        

        <TextoEstilizado>CUIDAR DA SUA SAÚDE NÃO É UMA
          TAREFA, É UM ESTILO DE VIDA!</TextoEstilizado>

        <LoginFormLogin>
          <SubmitButton className="submit-button">CADASTRE-SE</SubmitButton>
          <SubmitButton>ENVIAR</SubmitButton>
          {/* <SendButtonLogin className="send-button">ENVIAR</SendButtonLogin> */}
        </LoginFormLogin>


      </DivEstilizada>
    </ContainerLogin>
  );
}

export default Principal;
