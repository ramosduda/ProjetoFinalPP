import styled from 'styled-components'

export const ContainerLogin = styled.div`
display: flex;
justify-content: center;
align-items: center;
flex-direction: column;
height: 100vh;
background-color: #77AB5B;
margin: auto;
`
export const LoginFormLogin = styled.form`
background-color: #578543;
// padding: 130px;
width: 30vw;
height: 60vh;

border-radius: 25px;
box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
display: flex; 
flex-direction: column;
justify-content: center;
align-items: center;
gap: 20px;
/* margin-left: 550px; */
`

export const SubmitButton = styled.button`
    background-color: #77AB5B;
    color: white;
    padding: 10px 25px;
    border: none;
    border-radius: 10px;
    font-size: 18px;
    cursor: pointer;
    transition: background-color 0.3s;
    /* margin-left: 10px; */
    /* margin-top: 90px; */
    /* width: -70px; */
    /* height: 100px; */
    width: 20vw;

    &:hover{
        background-color: #77AB5B;
}
`
export const TittleLogin = styled.h1`
    color: #FFF;
    font-family: Baloo Paaji;
    font-size: 60px;
    font-style: normal;
    font-weight: 400;
    line-height: normal;

`
export const SendButtonLogin = styled.button`
background-color: #77AB5B;
    color: white;
    padding: 10px 25px;
    border: none;
    border-radius: 10px;
    font-size: 18px;
    cursor: pointer;
    transition: background-color 0.3s;
    margin-left: 10px;
    margin-top: -100px;
    width: -70px;
    height: 100px;
    

    &:hover{
        background-color: #77AB5B;
}
`
export const DivEstilizada = styled.div`
    
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 15vw;

`
export const TextoEstilizado = styled.p`
    width: 30vw;
    font-size: 39px;
    font-family: "https://fonts.google.com/specimen/Baloo+Paaji+2";
    color: #ffffff;
    gap: 10vw;
    font-family: Bai Jamjuree;
`